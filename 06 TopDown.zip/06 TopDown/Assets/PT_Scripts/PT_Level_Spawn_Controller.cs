﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PT_Level_Spawn_Controller : MonoBehaviour {
    public List<GameObject> prefabList;

    public List<GameObject> spawnPoints;

    public int[,] levelDataArray = new int[10,100];

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
