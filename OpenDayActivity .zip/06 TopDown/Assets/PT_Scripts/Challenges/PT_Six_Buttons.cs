﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PT_Six_Buttons : MonoBehaviour {

    /*
    * 
    *    Create a script that manages a list with 6 items in it and 6 buttons on screen and put words in some of the list entries. 
    *    When the list entry has a word in it change the word on the button. When the list has nothing in it disable the button. 
    * 
    */

       // Use this for initialization
       void Start () {

       }

       // Update is called once per frame
       void Update () {

       }
   }
